package com.lanou3g.yesterday;

public class DateBaseUtil<T> {
    public  void save(T t){

    }
    public T findById(int id){
        return null;
    }
}

