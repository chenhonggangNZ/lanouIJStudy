package com.lanou3g.yesterday.two;

public interface OperateDB<T> {
    T operate(T t);
}
