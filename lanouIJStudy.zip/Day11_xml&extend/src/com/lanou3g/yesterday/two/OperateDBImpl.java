package com.lanou3g.yesterday.two;

public class OperateDBImpl<T> implements OperateDB<T> {
    @Override
   public T operate(T t){
        return null;
    }
}
