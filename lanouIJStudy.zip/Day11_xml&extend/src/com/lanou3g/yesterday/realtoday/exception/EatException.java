package com.lanou3g.yesterday.realtoday.exception;

public class EatException extends Exception {

}
