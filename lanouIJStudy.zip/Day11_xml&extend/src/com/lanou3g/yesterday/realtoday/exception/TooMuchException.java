package com.lanou3g.yesterday.realtoday.exception;

import java.io.File;
import java.io.FileOutputStream;

public class TooMuchException extends EatException {

    @Override
    public String getMessage() {


        return "不知不觉，撑死了";

    }
}
