import java.util.HashMap;
import java.util.Map;

public class Test {

    public static void main(String[] args) {
        Map map = new HashMap();
        map.put("","");
    }
}
