public class MainMain extends Main {
}
